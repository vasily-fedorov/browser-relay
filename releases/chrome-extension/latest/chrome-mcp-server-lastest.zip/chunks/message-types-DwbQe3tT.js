//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region common/message-types.ts
/**
* Message type constants shared by the popup, background, offscreen document
* and injected content helpers.
*/
var MessageTarget = /* @__PURE__ */ function(MessageTarget) {
	MessageTarget["Offscreen"] = "offscreen";
	MessageTarget["ContentScript"] = "content_script";
	MessageTarget["Background"] = "background";
	return MessageTarget;
}({});
/** Popup <-> background messages that drive the relay connection. */
var RELAY_MESSAGE_TYPES = {
	CONNECT: "relay_connect",
	DISCONNECT: "relay_disconnect",
	GET_STATE: "relay_get_state",
	STATE_CHANGED: "relay_state_changed"
};
var OFFSCREEN_MESSAGE_TYPES = {
	GIF_ADD_FRAME: "gifAddFrame",
	GIF_FINISH: "gifFinish",
	GIF_RESET: "gifReset"
};
var TOOL_MESSAGE_TYPES = {
	SCREENSHOT_PREPARE_PAGE_FOR_CAPTURE: "preparePageForCapture",
	SCREENSHOT_GET_PAGE_DETAILS: "getPageDetails",
	SCREENSHOT_GET_ELEMENT_DETAILS: "getElementDetails",
	SCREENSHOT_SCROLL_PAGE: "scrollPage",
	SCREENSHOT_RESET_PAGE_AFTER_CAPTURE: "resetPageAfterCapture",
	WEB_FETCHER_GET_HTML_CONTENT: "getHtmlContent",
	WEB_FETCHER_GET_TEXT_CONTENT: "getTextContent",
	CLICK_ELEMENT: "clickElement",
	FILL_ELEMENT: "fillElement",
	SIMULATE_KEYBOARD: "simulateKeyboard",
	GET_INTERACTIVE_ELEMENTS: "getInteractiveElements",
	GENERATE_ACCESSIBILITY_TREE: "generateAccessibilityTree",
	RESOLVE_REF: "resolveRef",
	ENSURE_REF_FOR_SELECTOR: "ensureRefForSelector",
	VERIFY_FINGERPRINT: "verifyFingerprint",
	DISPATCH_HOVER_FOR_REF: "dispatchHoverForRef",
	NETWORK_SEND_REQUEST: "sendPureNetworkRequest",
	WAIT_FOR_TEXT: "waitForText",
	ELEMENT_PICKER_START: "elementPickerStart",
	ELEMENT_PICKER_STOP: "elementPickerStop",
	ELEMENT_PICKER_SET_ACTIVE_REQUEST: "elementPickerSetActiveRequest",
	ELEMENT_PICKER_UI_PING: "elementPickerUiPing",
	ELEMENT_PICKER_UI_SHOW: "elementPickerUiShow",
	ELEMENT_PICKER_UI_UPDATE: "elementPickerUiUpdate",
	ELEMENT_PICKER_UI_HIDE: "elementPickerUiHide",
	ELEMENT_PICKER_UI_EVENT: "element_picker_ui_event",
	ELEMENT_PICKER_FRAME_EVENT: "element_picker_frame_event"
};
TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_EVENT, TOOL_MESSAGE_TYPES.ELEMENT_PICKER_FRAME_EVENT;
//#endregion
export { OFFSCREEN_MESSAGE_TYPES as n, RELAY_MESSAGE_TYPES as r, MessageTarget as t };
